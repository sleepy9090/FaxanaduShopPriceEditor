﻿FaxanaduShopEditor 1.0.0.29336
Coded by: Shawn M. Crawford [sleepy9090]
April 29, 2018

-Requires .NET Framework 3.5

FaxanaduShopEditor 
Shop Editor for Faxanadu USA NES
Change prices for items in shops.
Change some shop dialogs.

-Tested with headered Faxanadu (U).nes with MD5 checksum E8D6013BFB2835D1331A2C973FB1C40B

Feel free to send bugs to sleepy3d@email.com or file them on github: https://github.com/sleepy9090

Version: 1.0.0.29336 April 29, 2018
-first version

